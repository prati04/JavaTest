package com.demo.test;
import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

import com.demo.bean.Person;
import com.demo.service.PersonService;

public class TestPersonArray {
	static {
		
		System.out.println("In static block");
	}
	 
	
	
      
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		//PersonService.acceptData();
		//i=12;
		int choice=0;
		do {
		System.out.println("1.Search person");
		System.out.println("2.modify Person\n 3.display all\n4. serach by name");
		System.out.println("5.exit");
		System.out.println("Choice: ");
		choice=sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("enter id");
			int id=sc.nextInt();
			Person p=PersonService.searchPerson(id);
			if(p!=null) {
				System.out.println(p);
			}
			else {
				System.out.println("not found");
			}
			break;
		case 2:
			System.out.println("enter id");
			id=sc.nextInt();
			System.out.println("enter mobile");
			String mob=sc.next();
			System.out.println("enter email");
			String email=sc.next();
			boolean status=PersonService.modifyData(id,mob,email);
			if(status) {
				System.out.println("updation done");
			}
			else {
				System.out.println("not found");
			}
			
			break;
		case 3:
			PersonService.dispalyData();
			break;
		case 4:
			System.out.println("enter name");
			String nm=sc.next();
			p=PersonService.searchByName(nm);
			 if(p!=null) {
					System.out.println(p);
				}
			else {
					System.out.println("not found");
				}
		
			break;
		case 5:
			System.exit(0);
			break;
		
		}
		}while(choice!=3);
		//PersonService.dispalyData();
		
		
		
	}

}
