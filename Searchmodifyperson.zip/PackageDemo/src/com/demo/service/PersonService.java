package com.demo.service;
import java.text.ParseException;
import java.text.*;
import java.util.Date;
import java.util.Scanner;

import com.demo.bean.Person;

public class PersonService {
	static Person[] parr;
	static SimpleDateFormat sdf;
	static {
		//i=10;
		sdf=new SimpleDateFormat("dd/MM/yyyy");
		parr=new Person[5];
		parr[0]=new Person(12,"Kishori","1111","aaa@ddd",new Date());
		parr[1]=new Person(13,"Revati","2222","bbb@ddd",new Date());
		parr[2]=new Person(14,"Rajan","33333","cccc@ddd",new Date());
		
	}
	//static int i;
	
	
	/*
	 * public PersonService() { parr=new Person[20]; }
	 */
	 
	
	
	public static void acceptData() {
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<parr.length;i++) {
			System.out.println("Enter Id");
			int id=sc.nextInt();
			System.out.println("enter name");
			String nm=sc.next();
			System.out.println("enter Mobile");
			String mob=sc.next();
			System.out.println("enter email");
			String em=sc.next();
			System.out.println("enetr Date(dd/mm/yyyy)");
			String dt=sc.next();
			Date jdt=null;
			try {
				 jdt=sdf.parse(dt);
				 
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				jdt=null;
			}
			parr[i]=new Person(id,nm,mob,em,jdt);
		}
	}
	
	public static void dispalyData() {
		for(int i=0;i<parr.length;i++) {
			System.out.println(parr[i]);
		}
	}

	public static Person searchPerson(int id) {
		for(int i=0;i<parr.length;i++) {
			if(parr[i].getId()==id) {
				return parr[i];
			}
		}
		return null;
		}

	public static Person searchByName(String nm) {
		for(int i=0;i<parr.length;i++) {
			if(parr[i].getName().equals(nm)) {
				return parr[i];
			}
		}
		return null;
	}

	public static boolean modifyData(int id, String mob, String email) {
		Person p=searchPerson(id);
		if(p!=null) {
		   p.setMobile(mob);
		   p.setEmail(email);
		   return true;
		}
		else {
		   return false;
		}
	}
		
	

}
