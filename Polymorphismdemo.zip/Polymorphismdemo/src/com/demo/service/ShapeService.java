package com.demo.service;

public interface ShapeService {
	void addData(int ch, int i);
	void displayAll();
	/*public static void mymethod() {
		System.out.println("this is static method");
	}
	default void mydefaultmethod() {
		System.out.println("this is default method");
	}*/
}
