package com.demo.Exceptions;

public class AgeException extends Exception {
   public AgeException(String msg) {
	   super(msg);
   }
}
