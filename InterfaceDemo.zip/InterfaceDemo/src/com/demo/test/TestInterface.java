package com.demo.test;

import com.demo.service.Interface1;
import com.demo.service.MyClassImpl;

public class TestInterface {

	public static void main(String[] args) {
		MyClassImpl ob=new MyClassImpl();
		ob.m22();
		Interface1 iob1=new MyClassImpl();
		iob1.m11();
		
		

	}

}
