package com.demo.service;

public class MyClassImpl implements Interface1,Interface2 {

	@Override
	public void m11() {
		System.out.println("In m11");
		
	}

	@Override
	public void m12(int x) {
		System.out.println("in m12");
		
	}

	@Override
	public int m21() {
		System.out.println("in m21");
		return 0;
	}

	@Override
	public void m22() {
		System.out.println("in m22");
		
	}

}
