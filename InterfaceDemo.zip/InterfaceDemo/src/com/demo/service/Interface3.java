package com.demo.service;

public interface Interface3 {
   void m31();
   void m32();
}
