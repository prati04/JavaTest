package com.demo.service;

public interface Interface1 {
	void m11();
	void m12(int x);
	int i=10;
}
