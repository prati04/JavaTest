package com.demo.service;

public interface Interface5 extends Interface3,Interface4{
	void m51();

}
