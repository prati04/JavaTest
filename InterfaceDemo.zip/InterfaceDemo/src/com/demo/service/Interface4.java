package com.demo.service;

public interface Interface4 {
   void m41();
   void m42();
}
