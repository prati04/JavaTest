package com.demo.service;

public interface Interface2 {
    int m21();
    void m22();
}
